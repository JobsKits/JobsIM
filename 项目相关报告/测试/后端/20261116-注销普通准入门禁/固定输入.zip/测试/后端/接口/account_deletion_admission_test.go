package jobsim

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"errors"
	"net/http/httptest"
	"testing"
)

func TestAccountDeletionAdmissionRejectsOrdinaryCredentialLanes(t *testing.T) {
	for _, state := range []string{"requested", "processing", "completed"} {
		t.Run(state, func(t *testing.T) {
			ctx, a, user, q, token, _ := newPasswordChangePGApp(t)
			tx, err := a.DB.Begin(ctx)
			if err != nil {
				t.Fatal("owned issuance transaction unavailable")
			}
			native, err := a.issueSession(ctx, tx, user, "gate-native", 1, 1, 1, false)
			if err != nil {
				tx.Rollback(ctx)
				t.Fatal("valid native family fixture failed")
			}
			web, err := a.issueSession(ctx, tx, user, "gate-browser", 1, 1, 1, true)
			if err != nil || tx.Commit(ctx) != nil {
				t.Fatal("valid browser family fixture failed")
			}
			pcExec(t, ctx, a, `UPDATE auth.sessions SET web_pending=false WHERE id=$1`, web.SessionID)
			pcExec(t, ctx, a, `UPDATE auth.bff_sessions SET state='active',browser_confirmed_at=now() WHERE session_id=$1`, web.SessionID)
			if _, err = a.browserSession(ctx, web.BrowserCookie); err != nil {
				t.Fatal("browser positive control failed before deletion state")
			}
			batch, code := newID(), "non-secret-owned-recovery-code"
			pcExec(t, ctx, a, `UPDATE auth.users SET recovery_generation=1 WHERE id=$1`, user.ID)
			pcExec(t, ctx, a, `INSERT INTO auth.recovery_code_batches(id,user_id,generation,active) VALUES($1,$2,1,true)`, batch, user.ID)
			pcExec(t, ctx, a, `INSERT INTO auth.recovery_codes(id,batch_id,code_digest) VALUES($1,$2,$3)`, newID(), batch, keyedDigest(a.Config.Key, "recovery", []byte(code)))
			grant := "non-secret-owned-password-reset-grant"
			pcExec(t, ctx, a, `INSERT INTO auth.reset_grants(id,user_id,purpose,credential_digest,issued_security_version,restore_epoch,expires_at,state,issue_request_id) VALUES($1,$2,'password_reset',$3,1,1,now()+interval '5 minutes','active',$4)`, newID(), user.ID, keyedDigest(a.Config.Key, "password-reset-grant", []byte(grant)), newID())
			originalHash := pcHash(t, ctx, a, user.ID)
			pcExec(t, ctx, a, `UPDATE auth.users SET deletion_state=$2 WHERE id=$1`, user.ID, state)
			proof, _ := json.Marshal(map[string]string{"token": token, "authorization": "Bearer " + token, "method": "GET", "path": "/api/me"})
			var denied *apiError
			if err = a.authorize(httptest.NewRecorder(), httptest.NewRequest("POST", "/internal/authorize", bytes.NewReader(proof))); !errors.As(err, &denied) || denied.Status != 401 {
				t.Fatal("ordinary access survived deletion state")
			}
			if _, err = a.browserSession(ctx, web.BrowserCookie); err == nil {
				t.Fatal("browser credentials survived deletion state")
			}
			call := func(path string, value any) *httptest.ResponseRecorder {
				raw, _ := json.Marshal(value)
				r := httptest.NewRequest("POST", path, bytes.NewReader(raw))
				r.Header.Set("Content-Type", "application/json")
				w := httptest.NewRecorder()
				a.Handler().ServeHTTP(w, r)
				return w
			}
			login := map[string]string{"username": q.Username, "password": q.CurrentPassword, "requestId": newID(), "deviceName": "new-auth-attempt"}
			if w := call("/api/auth/login", login); w.Code != 401 {
				t.Fatal("fresh password login reopened an account in deletion")
			}
			if w := call("/api/auth/refresh", refreshRequest{RefreshToken: native.Result.RefreshToken, RequestID: newID(), FamilyID: native.Result.FamilyID, RefreshGeneration: "1"}); w.Code != 401 || !bytes.Contains(w.Body.Bytes(), []byte("REFRESH_REAUTH_REQUIRED")) {
				t.Fatal("valid refresh family rotated across deletion state")
			}
			for _, recovery := range []struct {
				path  string
				value map[string]string
			}{
				{"/api/auth/recover", map[string]string{"username": q.Username, "password": q.NewPassword, "requestId": newID(), "code": code}},
				{"/api/auth/reset-password", map[string]string{"username": q.Username, "password": q.NewPassword, "requestId": newID(), "grant": grant}},
			} {
				if w := call(recovery.path, recovery.value); w.Code != 403 {
					t.Fatal("valid recovery proof bypassed deletion state")
				}
			}
			if w := pcCall(a, "/api/auth/password-change", token, q); w.Code != 401 {
				t.Fatal("ordinary password change bypassed deletion state")
			}
			raw, _ := json.Marshal(map[string]string{"userId": user.ID, "deviceId": user.DeviceID})
			r := httptest.NewRequest("POST", "/internal/exports/principal", bytes.NewReader(raw))
			r.Header.Set("Content-Type", "application/json")
			r.Header.Set("X-JobsIM-Service-Key", base64.RawURLEncoding.EncodeToString(a.Config.Key))
			w := httptest.NewRecorder()
			a.Handler().ServeHTTP(w, r)
			if w.Code != 403 {
				t.Fatal("formal export granted a deleted/pending-deletion principal")
			}
			if pcHash(t, ctx, a, user.ID) != originalHash || pcCount(t, ctx, a, `SELECT count(*) FROM auth.recovery_codes WHERE consumed_at IS NOT NULL`) != 0 || pcCount(t, ctx, a, `SELECT count(*) FROM auth.reset_grants WHERE state<>'active'`) != 0 || pcCount(t, ctx, a, `SELECT count(*) FROM journal.entries`) != 0 {
				t.Fatal("rejected ordinary lane changed credential, consumed recovery proof or added safety facts")
			}
			if pcCount(t, ctx, a, `SELECT count(*) FROM auth.sessions WHERE user_id=$1`, user.ID) != 4 {
				t.Fatal("rejected ordinary lane issued another session family")
			}
		})
	}
}

func TestAccountDeletionAdmissionRetiresPreparedPasswordChange(t *testing.T) {
	ctx, a, user, q, _, _ := newPasswordChangePGApp(t)
	value, err := a.preparePasswordChange(ctx, user, q)
	if err != nil {
		t.Fatal("prepared positive control failed")
	}
	old := pcHash(t, ctx, a, user.ID)
	pcExec(t, ctx, a, `UPDATE auth.users SET deletion_state='requested' WHERE id=$1`, user.ID)
	if err = a.finishPasswordChange(ctx, value); err != nil || pcHash(t, ctx, a, user.ID) != old {
		t.Fatal("prepared credential operation installed a hash after deletion admission closed")
	}
	if pcCount(t, ctx, a, `SELECT count(*) FROM auth.password_changes WHERE state='retired' AND octet_length(replacement_hash_ciphertext)=0`) != 1 {
		t.Fatal("retired password operation retained secret recovery material")
	}
}

func TestAccountDeletionAdmissionHistoricalPasswordResultIsNotCurrent(t *testing.T) {
	ctx, a, user, q, token, _ := newPasswordChangePGApp(t)
	if pcCall(a, "/api/auth/password-change", token, q).Code != 200 {
		t.Fatal("completed positive control failed")
	}
	pcExec(t, ctx, a, `UPDATE auth.users SET deletion_state='requested' WHERE id=$1`, user.ID)
	if w := pcCall(a, "/api/auth/password-change-results", "", q); w.Code != 200 || pcBody(t, w)["current"] != false {
		t.Fatal("historical password result called pending-deletion account current")
	}
}
